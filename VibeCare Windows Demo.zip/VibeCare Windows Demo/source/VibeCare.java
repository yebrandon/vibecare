import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.File; 
import java.util.Random; 
import java.text.DateFormatSymbols; 
import java.io.*; 
import java.io.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class VibeCare extends PApplet {

public static int currency;
int time = millis(),screen;
Tracker tracker = new Tracker();
Journal journal = new Journal("journal.txt",width/8,height/5);
Button menu[] = new Button[5],packs [] = new Button [3];
Bar bar;
imageDatabase img;
Collection collect;
Vibe [] vibes;
PFont font;
final int BACKGROUND = 255,TEST = 0xff000000,BUTTON = 0xff009478,BAR = 0xff00A878;
PImage image;
String purchase = "";
String[] personInfo;
textReader tr = new textReader("person.txt",width/8,height/5);;

public void setup() 
{
  
  
  personInfo=loadStrings("person.txt");
  if(personInfo.length == 0||personInfo[0].length() == 0||personInfo.equals(" ")){
    bar = new Bar("", "MENU", 0, BAR);
    screen = -1;
  }else{
  bar = new Bar(personInfo[0], "MENU", 0, BAR);
  screen = 0;
  }
  surface.setTitle("Vibe Care");
  font = loadFont("font.vlw");
  String [][] info;
  info = initializeInfo();
  img = new imageDatabase();
  vibes = img.initializeVibe(info);
  collect = new Collection(vibes);
  image = loadImage("logo.png");

  for (int i=0; i < menu.length; i++) 
  {
    menu[i] = new Button(width/5, width/12, BUTTON);
  }

  for (int i=0; i < packs.length; i++) 
  {
    packs[i] = new Button(i*width/3+20, 200, TEST);
  }

  menu[0].setText("Home\nScreen");
  menu[1].setText("Journal");
  menu[2].setText("Tracker");
  menu[3].setText("Collection");
  menu[4].setText("Store");
}

public void draw() 
{
  if ((millis() > time + 10000) && screen != 2)
  {
    time = millis();
    tracker.done = false;
    tracker.habitIndex = 0;
  }
  background(BACKGROUND);
  textFont(font);

  for (int i=0; i< menu.length; i++) 
  {
    menu[i].update(i*(width/5)+7);
  }

  if (menu[0].isOver()||menu[1].isOver()||menu[2].isOver()||menu[3].isOver()||menu[4].isOver())
  {
    cursor(HAND);
  } else
  {
    cursor(ARROW);
  }
  if (screen ==-1){
    tr.promptEntry("Hey there! Welcome to Vibe Care! Please enter your name to begin!");
    tr.displayText(width/2,height/2);
  }
  if (screen == 0)
  {
    tint(255);
    imageMode(CENTER);
    image(image, width/2, height/2);
    imageMode(CORNER);
  }
  if (screen == 1)
  {
    if(journal.entryDone)
    {
      screen = 7;
    }
    else
    {
      journal.promptEntry("Type a new journal entry for today!");
    }
  }
  if(screen == 7)
  {
    //read from file and display
    journal.displayText(); 
  }
  if (screen == 2)
  {
    if (!tracker.done)
    {
      tracker.askHabit(tracker.habitIndex);
    } else
    {
      tracker.habitIndex++;
      tracker.done = false;
      bar.total++;
    }
    if (tracker.habitIndex > tracker.habits.length-1)
    {
      tracker.displaySummary();
    }
  }
  if (screen == 3)
  {
    collect.display();
  }
  if (screen == 4)
  {
    
    img.display();
    for(int i=0; i < packs.length; i++)
    {
      //packs[i].createButton(i*width/3+20, 200, TEST);
      //vibes = img.initializeVibe(initialize(info));
    }
    if(packs[0].isOverPack() && bar.getTotal() >= 30 && mousePressed) 
    {
      mousePressed = false;
      int index = img.cheapPack();
      int reduce = bar.getTotal();
      reduce -= 30;
      print (index);
      bar.setAmount (reduce);
      vibes [index].setAchieved (true);
      purchase = "You recieved " + vibes[index].name + ", a " + rarityToWord(vibes[index].rarity) + " vibe!";
    } else if (packs[1].isOverPack() && bar.getTotal() >= 60 && mousePressed) {
      mousePressed = false;
      int index = img.mehPack();
      int reduce = bar.getTotal();
      reduce -= 60;
      print (index);
      bar.setAmount (reduce);
      vibes [index].setAchieved (true);
      purchase = "You recieved " + vibes[index].name + ", a " + rarityToWord(vibes[index].rarity) + " vibe!";
    } else  if (packs[2].isOverPack() && bar.getTotal() >= 150 && mousePressed) {
      mousePressed = false;
      int index = img.expensivePack();
      int reduce = bar.getTotal();
      reduce -= 150;
      print (index);
      bar.setAmount (reduce);
      vibes [index].setAchieved (true);
      purchase = "You recieved " + vibes[index].name + ", a " + rarityToWord(vibes[index].rarity) + " vibe!";
    }
    text(purchase,width/2,9*height/10);
  }
  
  bar.display();
}  

public void mousePressed() {
  if(screen!=-1){
  if (menu[0].isOver()) {
    screen=0;
    bar.setTitle("MENU");
  } else if (menu[1].isOver()) {
    screen=1;
    bar.setTitle("JOURNAL");
  } else if (menu[2].isOver()) {
    screen=2;
    bar.setTitle("TRACKER");
  } else if (menu[3].isOver()) {
    screen=3;
    bar.setTitle("COLLECTION");
  } else if (menu[4].isOver())
  {
    screen = 4;
    bar.setTitle("STORE");
  }
  }
}

public void keyPressed()
{
  if(screen == 1){  
  journal.type();
  if(journal.entryDone()){
  screen = 7;
  }
  }if(screen == -1){  
  tr.type();
  if(tr.entryDone()){
    bar = new Bar(tr.entry, "MENU", 0, BAR);
    screen=0;
  }
  }
}
/**
  Class for creating the menu bar. Includes users name, screen title, 
  and total amount of money.
  
   @author Barrett
   @version Feb 1st, 2020
``**/

class Bar
{
  private String name;
  private String title;
  private int total;
  private final int WIDTH = width/16;
  private int colour;
  
  public Bar(String name, String title, int total, int colour)
  {
    this.name = name;
    this.title = title;
    this.total = 10000; //DEMO ONLY
    this.colour = colour;
  }
  
  //Accessors
  public int getTotal()
  {
    return total;
  }
  
  public String getTitle()
  {
    return title;
  }
  
  public String getYName()
  {
    return name;
  }
  
  private void setYName(String newName)
  {
    name = newName;
  }
  
  private void setTitle(String newTitle)
  {
    title = newTitle;
  }
  
  private void setAmount(int amount)
  {
    total = amount;
  }
  
  private void display()
  {
    fill(colour);
    noStroke();
    textSize(20);
    rect(0, 0, width, WIDTH);
    
    //name
    fill(0);
    textAlign(LEFT);
    text((this.name).toUpperCase(), 0, WIDTH/2);
    
    textAlign(RIGHT);
    text(formatCoin(total), width, WIDTH/2);
    
    textAlign(CENTER);
    text(this.title, width/2, WIDTH/2);
  }
  
  private String formatCoin(int total)
  {
    String formated = total + " CareCoins";
    
    return formated;
  }
  
}
/**
  Class for button formatting.
  
   @author Terry
   @version Feb 1st, 2020
``**/
public class Button {
  private String name = "";
  private int xPos, yPos;
  final int BUT_SIZE_X = 125, BUT_SIZE_Y = 50;
  private int colour;

  public Button(String inputName, int inputX, int inputY) {
    name=inputName;
    xPos=inputX;
    yPos=inputY;
    createButton();
  }
  
  public Button(int inputX, int inputY, int colour) {
    xPos = inputX;
    yPos = inputY;
    this.colour = colour;
    createButton();
  }
  
  //public Button(int inputX, int inputY) {
  //  xPos = inputX;
  //  yPos = inputY;
  //  createButton();
  //}
  
  private void createButton() {
    strokeWeight(5);
    fill(colour);
    rect(xPos, yPos, BUT_SIZE_X, BUT_SIZE_Y, 12);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(BUT_SIZE_Y/3);
    text(name, (BUT_SIZE_X/2)+xPos, (BUT_SIZE_Y/2)+yPos);
  }
  
  public void createButton (int x, int y){
    fill(colour);
    rect(x, y, 200, 200);
    fill(0);
  }  
  
  public void setText(String inputName) {
    name=inputName;
    createButton();
  }
  
  public int getX() {
    return xPos;
  }

  public int getY() {
    return yPos;
  }

  public void update(int newPos) {
    xPos=newPos;
    createButton();
  }
  
  public boolean isOver() {
    return (mouseX>xPos) && (mouseX<xPos+BUT_SIZE_X) && (mouseY>yPos) && (mouseY<yPos+BUT_SIZE_Y);
  }
  
  public boolean isOverPack() {
    return (mouseX>xPos) && (mouseX<xPos+200) && (mouseY>yPos) && (mouseY<yPos+400);
  }
}
/**
  Collection Object?
 **/

class Collection
{
  private Vibe [] collection;
  //private imageDatabase collection;
  private boolean display;
  
  public Collection(Vibe [] collection)
  {
    this.collection = collection;
  }
  
  private void window()
  {
    rect(width/14, width/5, (width/14)*12, height - (width/7)*2);
  }
  
  private void display()
  {
    window();
    int y = 0;
    int x = 0;
    
    for(int i = 0; i < collection.length; i++)
    {
      collection[i].getImage().resize(75, 75);
      
      if(x > 10)
      {
        x = 0;
        y += 60;
      }
      
      if(collection[i].achieved() == true)
      {
        tint(255);
      }
      else
      {
        tint(25,25,25);
      }
      
      collection[i].displayImage((x*width/14)+50, (width/5)+y);
      x++;
    }
  }
  
  
  //public void shown
  
}



public static int [] rarity = new int[0];

public class imageDatabase {
  PImage img, img2;
  Vibe [] vibes;
  
  public String [] getFileNames (){
    File folder;
    String [] filenames;
    folder = new java.io.File (dataPath ("images"));
    filenames = folder.list();
    return filenames;
  } 
  
  public String [] getFileNames2 (){
    File folder;
    String [] filenames;
    folder = new java.io.File (dataPath ("packs"));
    filenames = folder.list();
    return filenames;
  } 
  
  public Vibe[] initializeVibe(String [][] info)
  {
      String [] filenames = getFileNames();
      Vibe [] vibes = new Vibe[filenames.length];
      
      for(int i = 0; i < filenames.length; i++) 
      {
        for(int j = 0; j < info[0].length; j++)
        {
          img = loadImage("images/" + filenames[i]);
          
          vibes[i] = new Vibe(info[i][0], img, false, assignVibe(filenames)[i]);
        }
      }
      return vibes;
  }
  
  public int [] assignVibe (String [] filenames){
    
    rarity = new int[filenames.length];
    
    for (int x = 0; x < rarity.length; x++) {
      if (x < rarity.length*0.5f){
          rarity [x] = 0;
      } 
      
      else if (x >= rarity.length*0.5f && x < rarity.length*0.8f){
          rarity [x] = 1;
      } 
      
      else {
          rarity [x] = 2;
      }  
    }
    return rarity;
  }
  
  public int cheapPack (){
  Random rand = new Random ();
  int vibeChooser = 0; 
  int rarityChooser = 0;
  int num = rarity.length; 
  float common = num*0.5f;
  float rare = num*0.8f; 
  int legendary = rarity.length;
   rarityChooser = rand.nextInt(100);
    
    // 85% chance of getting a common (5/100)
    if (rarityChooser < 85){
      // choose a random common
      vibeChooser = (int) (Math.random()*common);
    }
    // 10% chance of getting a rare (5/100)
    else if (rarityChooser >= 85 && rarityChooser < 95){
      // choose a random rare
      vibeChooser = (int) (Math.random()*(rare-common)+common);
    }
    else {
      vibeChooser = (int) (Math.random()*(legendary-rare)+common);      
    }  
    return vibeChooser;
  }
  
  public int mehPack () 
  {
    Random rand = new Random ();
    int vibeChooser = 0; 
    int rarityChooser = 0;
    int num = rarity.length; 
    float common = num*0.5f;
    float rare = num*0.8f; 
    int legendary = rarity.length;
    rarityChooser = rand.nextInt(100);
    
    // 75% chance of getting a common (5/100)
    if (rarityChooser < 50){
      // choose a random common
      vibeChooser = (int) (Math.random()*common);
    }
    // 10% chance of getting a rare (5/100)
    else if (rarityChooser >= 50 && rarityChooser <85){
      // choose a random rare
      vibeChooser = (int) (Math.random()*(rare-common)+common);
    }
    else {
      vibeChooser = (int) (Math.random()*(legendary-rare)+common);      
    }  
    return vibeChooser;
  }
  
 public int expensivePack ()
 {
    Random rand = new Random ();
    int vibeChooser = 0; 
    int rarityChooser = 0;
    int num = rarity.length; 
    float common = num*0.5f;
    float rare = num*0.8f; 
    int legendary = rarity.length;
    rarityChooser = rand.nextInt(100);
    
    // 85% chance of getting a common (5/100)
    if (rarityChooser < 30){
      // choose a random common
      vibeChooser = (int) (Math.random()*common);
    }
    // 10% chance of getting a rare (5/100)
    else if (rarityChooser >= 30 && rarityChooser < 75){
      // choose a random rare
      vibeChooser = (int) (Math.random()*(rare-common)+common);
    }
    else {
      vibeChooser = (int) (Math.random()*(legendary-rare)+common);      
    }  
    return vibeChooser;
  }
  
  public void display () 
  {
     tint(255);
     String [] filenames = getFileNames2();
     for (int i = 0; i < filenames.length; i++) {
       img = loadImage ("packs/" + filenames[i]);
        
        //hi bart, ignore this for now, this is just formatting for the store

       image (img, i*width/3+20, 200);
    }
   }
  }
public String [][] initializeInfo()
{
  String [] info;
  info = loadStrings("info.txt");
  String [][] tokens = new String[info.length][];


  for (int i = 0; i < info.length; i++)
  {
    tokens[i] = splitTokens(info[i], ",");
  }

  return tokens;
}
/**
  tracking the VIBES
  
   @author Brandon
   @version Feb 1st, 2020
``**/




class Journal extends textReader
{
  public String date = getMonth(month()) + "  " + Integer.toString(day()) +  ",  " + Integer.toString(year());
  
  public Journal(String temp, int xPos, int yPos){
    super(temp, xPos, yPos);
  }
  
  public String getMonth(int month)
  {
    return new DateFormatSymbols().getMonths()[month-1];
  }
  
  public void type()
  {
      // If the return key is pressed, save the String and clear it
      if (key == '\n' ) 
      {
        entry = input;
        entry = entry.replaceAll("[\n]", "");
        input = "";
        //write to file
        String[] lines = loadStrings(address);
        lines = append(lines,date);
        lines = append(lines,entry);
        lines = append(lines,"\n");
        saveStrings(address,lines);
        input = "";
        entryDone = true;
        bar.total++;
        
      }
      
      if (key == BACKSPACE)
      {
        if(input.length() > 0)
        {
          input = input.substring(0, input.length()-1);
        }
      }
      else 
      {
        // Otherwise, concatenate the String
        // Each character typed by the user is added to the end of the String variable.
        input = input + key; 
      }
  }
    public void promptEntry(String entry)
  {
    
    textAlign(LEFT);
    text (date, width/8, (height/5));
    text (entry, width/8, (height/5)+20);
    text (input, width/8, (height/5)+40);
    
   }
 }
  
  



  
  
  

  
/**
  tracking the VIBES
  
   @author Brandon
   @version Feb 1st, 2020
``**/

class Tracker
{
  public String[] habits = {"Exercise for 30 minutes every day", "Floss every day", "Go to bed before 11 PM"}; //read habits from text file
  public int[] habitAnswers = new int[habits.length];
  boolean done = false;
  int habitIndex = 0;
  final int BUTTON = 0xff009478;
  public Tracker()
  {

  }
  
 
  
  public void displaySummary()
  {
    final int FORMAT = width/6;
    int g = 168;
    textSize(15);
    noStroke();
    for(int i = 0; i < habits.length; i++)
    {
      g -= 20;
      fill(0, g, 120);
      rect(0, (((height-FORMAT)/habits.length)*i)+FORMAT, width/2, (height-FORMAT)/habits.length);
      fill(0);
      textAlign(CENTER);
      text(habits[i], width/5, (((height-FORMAT)/habits.length)*i)+FORMAT*2); //height-100-(i*(height/habits.length))
      if(habitAnswers[i] == 1)
      {
        fill(0);
        textAlign(LEFT);
        text ("You kept up your habit, nice work!", 3*width/5, (((height-FORMAT)/habits.length)*i)+FORMAT*2);
      }
      else
      {
        fill(0);
        textAlign(LEFT);
        text ("You missed your habit this time, \nbut don't give up!", 3*width/5, (((height-FORMAT)/habits.length)*i)+FORMAT*2);
      }
    }
    fill(0, g, 120);
    rect(0, width/6, width, 20);
    
    fill(0);
    textSize(15);
    textAlign(CENTER);
    text("HABIT TRACKING SUMMARY", width/2, FORMAT+15);
  }
          
public void askHabit(int count)
  {
    if(!done && habitIndex < habits.length)
    {
      textAlign(CENTER);
      text("Do you think you've kept up with this habit today?",width/2,height/2-75);
      text(habits[count], width/2, height/2-50);
      Button yes = new Button(width/4+25, (height/2), BUTTON);
      yes.setText("Yes");
      Button no = new Button(2*width/4+25, (height/2), BUTTON);
      no.setText("No");
     
      if(yes.isOver())
      {
        cursor(HAND);
        if (mousePressed)
        {
          mousePressed = false;
          done = true;
          habitAnswers[habitIndex] = 1;
        }
      }
      else if (no.isOver())
      {
        cursor(HAND);
        if (mousePressed)
        {
          mousePressed = false;
          done = true;
          habitAnswers[habitIndex] = 0;
        }
      }
    }
  }

}
  
  
  

  
  
/**
  Class for the vibe object.
  
   @author 
   @version Feb 1st, 2020
``**/

public class Vibe 
{
  private String name;
  private PImage image;
  private boolean achieved;
  private int rarity;

  public Vibe(String vibeName, PImage vibeImage, boolean acheived, int rarity) {
    name = vibeName;
    image = vibeImage;
    this.rarity = rarity;
    this.achieved = acheived;
  }
  public String getName() {
    return name;
  }
  public PImage getImage() {
    return image;
  }
  
  public void setAchieved (boolean tf) {
    this.achieved = tf;
  }
  
  //Checks whether the "vibe" is in the users possession
  public boolean achieved()
  {
    return achieved;
  }
  
  public void displayImage(int xPos, int yPos)
  {
    image(image, xPos, yPos);
  }
  
}
public String rarityToWord(int rarity)
{
 if(rarity ==0)
 {
   return "common";
 }
 else if(rarity == 1)
 {
   return "rare";
 }
 else
 {
   return "legendary";
 }
}



class textReader
{
  public String input = "";
  public String entry= "";  
  boolean entryDone = false;
  String address;
  int xPos,yPos;
  
  public textReader(String temp, int inputX, int inputY){
    address=temp;
    int xPos=width/8;
  }
  
  public void displayText()
  {
    textAlign(LEFT); 
    text("My Journal Entries",width/8,height/5);
    String[] lines = loadStrings(address);
    for (int i = 0; i < lines.length; i++)
    {
      text(lines[i],width/8,(height/5)+(20*i) + 20);
    }
  }
  public void displayText(int inputX, int inputY)
  {
    String[] lines = loadStrings(address);
    textAlign(LEFT); 
    for (int i = 0; i < lines.length; i++)
    {
      text(lines[i],inputX,inputY+(20*i));
    }
  }
  
  public void type()
  {
      // If the return key is pressed, save the String and clear it
      if (key == '\n' ) 
      {
        entry = input;
        entry = entry.replaceAll("[\n]", "");
        input = "";
        //write to file
        String[] lines = loadStrings(address);
        lines = append(lines,entry);
        lines = append(lines,"\n");
        saveStrings(address,lines);
        input = "";
        entryDone = true;
        
      }
      
      if (key == BACKSPACE)
      {
        if(input.length() > 0)
        {
          input = input.substring(0, input.length()-1);
        }
      }
      else 
      {
        // Otherwise, concatenate the String
        // Each character typed by the user is added to the end of the String variable.
        input = input + key; 
      }
  }
    public void promptEntry(String entry)
  {
    
    textAlign(LEFT);
    text (entry, width/8, (height/5)+20);
    text (input, width/8, (height/5)+40);
    
   }
   public boolean entryDone(){
     return entryDone;
   }

 }
  
  



  
  
  

  
  public void settings() {  size(700, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "VibeCare" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
